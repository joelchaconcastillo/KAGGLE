#ifndef _LS_H_
#define _LS_H_

//#include "global.h"
//#include "individual.h"
void LS1(vector<CIndividual> &child_pop)
{

}

#endif
