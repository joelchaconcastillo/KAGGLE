#ifndef TSP_SANTA_LOCAL_SEARCH
#define TSP_SANTA_LOCAL_SEARCH

#include "tsp-santa-evaluation.h"
#include <time.h> 
#include <stdbool.h>

typedef struct{
  int rows; 
  int cols; 
  int ** ids;
} IdsMatrix; 
void free_idsmatrix(IdsMatrix mat); 

typedef struct{
  int a_pos; 
  int b_pos; 
  int a_index; 
  int b_index; 
  bool restarted; 
  Path path; 
  int * city_pos; 
  IdsMatrix nearest; 
  int * indexes; 
}Neighborhood; 

void free_neighborhood(Neighborhood ng); 

// Cargar los ids de las ciudades vecinas
IdsMatrix load_nearest_cities(Inst inst);

// Inicializa la vecindad 
Neighborhood create_neighborhood(Inst inst,Path init_sol);

// Actualiza la vecindad al siguiente vecino 
bool next_two_opt_neighbor(Neighborhood * ng); 

// Reinicia la vecindad
void reset_neighborhood(Neighborhood * ng); 

// Realiza una búsqueda local con vecindad 2opt
Path two_opt_local_search(Inst inst, Path init_sol); 

// Invierte el segmento 
void two_opt_move(Neighborhood * ng);



#endif
