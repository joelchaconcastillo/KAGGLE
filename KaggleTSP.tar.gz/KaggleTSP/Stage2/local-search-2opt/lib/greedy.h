#ifndef TSP_SANTA_GREEDY
#define TSP_SANTA_GREEDY

#include "tsp-santa-evaluation.h" 


// Calcula un recorrido calculando de forma aleatoria entre los 'k' 
// elementos más cercanos.
Path nearest_neighbors(Inst inst); 



#endif
