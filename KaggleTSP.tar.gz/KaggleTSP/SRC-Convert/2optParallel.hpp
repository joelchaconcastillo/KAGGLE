#ifndef _INCL_2OPTPARALLEL
#define _INCL_2OPTPARALLEL
///LS variables..

void ls2optparallel(){
    for(int i = 0; i < NCITIES; i++)
    {
    }
}
#endif
